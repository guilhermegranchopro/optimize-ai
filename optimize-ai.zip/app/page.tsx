"use client"

import RootLayout from "../src/app/layout"

export default function SyntheticV0PageForDeployment() {
  return <RootLayout />
}